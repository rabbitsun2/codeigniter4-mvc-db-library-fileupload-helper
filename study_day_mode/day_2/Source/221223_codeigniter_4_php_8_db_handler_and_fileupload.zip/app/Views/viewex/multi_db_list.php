<?php

    foreach($hello as $row){   

        echo $row['num'] . "&nbsp;";
        echo $row['title'] . "&nbsp;";
        echo $row['body'] . "&nbsp;";
        echo $row['totalpage'] . "&nbsp;";
        echo $row['author'] . "<br>";

    }

?>